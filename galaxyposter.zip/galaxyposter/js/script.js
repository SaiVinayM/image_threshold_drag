    var base64string = "images/ff1.jpg",
    ctx = document.createElement("canvas").getContext("2d"), // 0..255
    threshold = 150,
    image = new Image();


image.onload = function () {
    var w = ctx.canvas.width = image.width,
        h = ctx.canvas.height = image.height;

    ctx.drawImage(image, 0, 0, w, h);      // Set image to Canvas context
    var d = ctx.getImageData(0, 0, w, h);  // Get image Data from Canvas context
    red = d.data[0];
    green = d.data[1];
    blue = d.data[2];
    alpha = d.data[3];
    console.log(red + " " + green + " " + blue + " " + alpha);
    console.log(d);

    for (var i = 0; i < d.data.length; i += 4) { // 4 is for RGBA channels
        // R=G=B=R>T?255:0
        d.data[i] = d.data[i + 1] = d.data[i + 2] = d.data[i + 1] >  threshold ? 255 : 0;
    }

    ctx.putImageData(d, 0, 0);             // Apply threshold conversion
//    document.body.appendChild(ctx.canvas);
    $("#resizable").append(ctx.canvas); // Show result

};

image.src = base64string;


$(function () {
//      $( "#resizable" ).resizable({
//        containment: "#container"
////        aspectRatio: 16 / 9
//      });
    var sliderBar = $("#slider-range-min");
    var sliderBar1 = $("#thresholdValue");
    $("#resizable").draggable({
        scroll: true
        // containment: "#container"
    });
    $("#resizable1").draggable({
        scroll: true
        // containment: "#container"
    });
    sliderBar.slider({
        range: "min",
        value: 50,
        min: 1,
        max: 200,
        slide: function (event, ui) {
            $("#amount").val(ui.value);
        }
    });
    sliderBar1.slider({
        range: "min",
        value: 150,
        min: 1,
        max: 225,
        slide: function (event, ui) {
            $("#amount").val(ui.value);
        }
    });
    $("#amount").val(sliderBar.slider("value"));
    var sliderValue = $("#amount").val();
    console.log(sliderBar.slider("value"));
    $('.ui-slider-handle').on('click mousemove', function(){
        $('canvas').width(sliderBar.slider("value")+ 'vh');
        $('canvas').height('auto');
        $('#resizable').width(sliderBar.slider("value")+ 'vh');
        $('#resizable').height('auto');
    });

    $(sliderBar1).on('blur change', function(){
        var w = ctx.canvas.width = image.width,
            h = ctx.canvas.height = image.height;

        ctx.drawImage(image, 0, 0, w, h);      // Set image to Canvas context
        var d = ctx.getImageData(0, 0, w, h);  // Get image Data from Canvas context
        red = d.data[0];
        green = d.data[1];
        blue = d.data[2];
        alpha = d.data[3];
        console.log(red + " " + green + " " + blue + " " + alpha);

        console.log(d);

        for (var i = 0; i < d.data.length; i += 4) { // 4 is for RGBA channels
            // R=G=B=R>T?255:0
            d.data[i] = d.data[i + 1] = d.data[i + 2] = d.data[i + 1] <= $("#thresholdValue").val() ? 0 : 255;
        }

        ctx.putImageData(d, 0, 0);             // Apply threshold conversion
//    document.body.appendChild(ctx.canvas);
        $("#resizable").append(ctx.canvas); // Show result

    });

    // ctx.fillStyle = "red";
    // ctx.fillRect(10, 10, 50, 50);
   
// on text input value change
    // $( "#yText" )
//         .keyup(function() {
//             var value = $( this ).val();
//             $( "#resizable1 myInstance1" ).text( value );
//         })
//         .keyup();
// });

// function copy() {
//     var imgData = ctx.getImageData(0, 0, w, h);
//     ctx.putImageData(imgData, 10, 70);
// }

// function fitInContainer() {
//    $('#containment-wrapper').children().attr('id','container');
// }
//
// function UnfitInContainer() {
//    // $('#containment-wrapper').children().attr('id','');
// }

// function ImgCenter() {
   //  var w = ctx.canvas.width = image.width,
   //      h = ctx.canvas.height = image.height;
   // var CanvasImage = $('#resizable');
   // var conWidth = $('#containment-wrapper').width();
   // var conHeight = $('#containment-wrapper').height();
   // var x = ((conWidth/2)-(w/2));
   // var y = ((conHeight/2)-(w/2));
   // console.log(x,y);
   // CanvasImage.position(x,y);
// }


$(function () {

    function findPos(obj) {
        var curleft = 0, curtop = 0;
        if (obj.offsetParent) {
            do {
                curleft += obj.offsetLeft;
                curtop += obj.offsetTop;
            } while (obj = obj.offsetParent);
            return { x: curleft, y: curtop };
        }
        return undefined;
    }

    function rgbToHex(r, g, b) {
        if (r > 255 || g > 255 || b > 255)
            throw "Invalid color component";
        return ((r << 16) | (g << 8) | b).toString(16);
    }
$('canvas').hover(function(e) {

    var pos = findPos(this);
    var x = e.pageX - pos.x;
    var y = e.pageY - pos.y;
    var coord = "x=" + x + ", y=" + y;
    var c = this.getContext('2d');
    var p = c.getImageData(x, y, 1, 1).data;
    var hex = "#" + ("000000" + rgbToHex(p[0], p[1], p[2])).slice(-6);
    console.log(coord + "<br>" + hex);

});


});

/*
 * dblclk2edit - jQuery inline edit plugin
 *
 * Version: 201212.1
 *
 * Copyright (c) 2012 Dima Tsvetkov
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * More info:
 *   http://www.dima.fi/jquery/dblclk2edit/
 *
 */
 

